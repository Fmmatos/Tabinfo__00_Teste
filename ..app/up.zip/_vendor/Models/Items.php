<?php

namespace Vendor\Models;

class Items extends __Model
{
    public $table = 'items';
    public $fillable__ = [];
    public $active__ = 1;

    public $order_all__ = [
    ];

}