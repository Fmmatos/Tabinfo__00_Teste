<?php

namespace Vendor\Models;

class OrdersReturn extends __Model
{
    public $table = 'orders_return';
    public $fillable__ = [];

}