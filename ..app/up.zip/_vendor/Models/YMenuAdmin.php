<?php

namespace Vendor\Models;

class YMenuAdmin extends __Model
{
    public $table = 'y_menu_admin';
    public $fillable__ = [];
    public $active__ = 1;

    public $order_all__ = [
    ];

}
