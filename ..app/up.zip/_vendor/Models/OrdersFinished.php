<?php

namespace Vendor\Models;

class OrdersFinished extends __Model
{
    public $table = 'orders_finished';
    public $fillable__ = [];

}