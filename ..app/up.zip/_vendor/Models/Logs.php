<?php

namespace Vendor\Models;

class Logs extends __Model
{
    public $table = 'logs';
    public $fillable__ = [];

}