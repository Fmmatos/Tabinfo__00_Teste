<?php

namespace Vendor\Models;

class Shippings extends __Model
{
    public $table = 'shippings';
    public $fillable__ = [];
    public $active__ = 1;

    public $order_all__ = [
    ];

}