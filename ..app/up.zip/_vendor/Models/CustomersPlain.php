<?php

namespace Vendor\Models;

class CustomersPlain extends __Model
{
    public $table = 'customers_plain';
    public $fillable__ = [];

}