<?php

namespace Vendor\Models;

class ZText extends __Model
{
    public $table = 'z_text';
    public $fillable__ = [];

}
