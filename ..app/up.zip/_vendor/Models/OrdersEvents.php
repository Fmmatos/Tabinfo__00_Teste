<?php

namespace Vendor\Models;

class OrdersEvents extends __Model
{
    public $table = 'orders_events';
    public $fillable__ = [];
    public $active__ = 1;

}