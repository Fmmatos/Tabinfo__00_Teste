<?php

namespace Vendor\Models;

class Texts extends __Model
{
    public $table = 'texts';
    public $fillable__ = [];
    public $active__ = 1;

    public $order_all__ = [
    ];

}
