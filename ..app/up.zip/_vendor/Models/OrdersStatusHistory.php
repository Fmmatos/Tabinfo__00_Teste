<?php

namespace Vendor\Models;

class OrdersStatusHistory extends __Model
{
    public $table = 'orders_status_history';
    public $fillable__ = [];

}