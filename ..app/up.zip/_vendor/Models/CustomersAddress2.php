<?php

namespace Vendor\Models;

class CustomersAddress2 extends __Model
{
    public $table = 'customers_address_2';
    public $fillable__ = [];
}