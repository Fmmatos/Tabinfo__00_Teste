<?php

namespace Vendor\Models;

class ProductsBrands extends __Model
{
    public $table = 'products_brands';
    public $fillable__ = [];
    public $active__ = 1;

    public $order_all__ = [
    ];

}