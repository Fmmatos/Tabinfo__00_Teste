<?php

namespace Vendor\Models;

class Newsletter extends __Model
{
    public $table = 'newsletter';
    public $fillable__ = [];
    public $active__ = 1;

}