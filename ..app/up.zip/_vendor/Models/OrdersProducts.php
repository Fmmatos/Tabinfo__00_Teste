<?php

namespace Vendor\Models;

class OrdersProducts extends __Model
{
    public $table = 'orders_products';
    public $fillable__ = [];

}