<?php

namespace Vendor\Models;

class OrdersStatus extends __Model
{
    public $table = 'orders_status';
    public $fillable__ = [];

    public $order_all__ = [
    ];

}