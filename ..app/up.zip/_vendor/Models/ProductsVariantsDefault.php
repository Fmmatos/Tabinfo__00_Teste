<?php

namespace Vendor\Models;

class ProductsVariantsDefault extends __Model
{
    public $table = 'products_variants_default';
    public $fillable__ = [];

}