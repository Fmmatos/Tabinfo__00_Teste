<?php

namespace Vendor\Models;

class Webhooks extends __Model
{
    public $table = 'webhooks';
    public $fillable__ = [];

}
