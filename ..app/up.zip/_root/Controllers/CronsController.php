<?php

namespace Root\Controllers;

use Illuminate\Http\Request;

class CronsController
{
    // INDEX
        public function index(Request $request): void
        {
        }
    // INDEX

}