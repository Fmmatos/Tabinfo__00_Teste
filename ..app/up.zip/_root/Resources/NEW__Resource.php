<?php

namespace Root\Resources;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Root\Mail\TextsMail;
use Root\Models\Campaigns;
use Root\Models\CampaignsStatus;
use Root\Models\CampaignsVideos;
use Root\Models\CustomersSaques;
use Root\Models\CustomersStatement;
use Vendor\Models\Customers;
use Vendor\Models\Orders;
use Vendor\Models\OrdersStatus;
use Vendor\Models\OrdersStatusHistory;
use Vendor\Models\Users;
use Vendor\Models\XSettings;

class NEW__Resource
{


    // FIELDS

        // MANUAL
            public static function fields(object $value, mixed $key, mixed $item, string $table): object
            {
                if(0){}


                // XXX
                    // if ($table == 'xxx') {
                    //     if($key == 'yyy'){
                    //     }
                    // }
                // XXX


                return $value;
            }
        // MANUAL
    // FIELDS










    // AUTOCOMPLETE
    // AUTOCOMPLETE










    // SEARCH
    // SEARCH










    // FIELDS DATATABLE
    // FIELDS DATATABLE










    // FIELDS CREATE EDIT
    // FIELDS CREATE EDIT










    // SAVE VALIDATE
    // SAVE VALIDATE
    
    
    
    
    
    
    
    
    
    
    // SAVE
    // SAVE










    // HTML_TABLE
    // HTML_TABLE










    // HTML_CREATE_EDIT
    // HTML_CREATE_EDIT


}